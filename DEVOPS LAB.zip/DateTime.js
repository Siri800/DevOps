const date = new Date();
console.log("Current Date & Time:", date.toLocaleString());
