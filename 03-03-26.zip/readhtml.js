const http = require('http');
const fs = require('fs');

http.createServer((req, res) => {
  fs.readFile('menubar.html', (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end("File not found");
    } else {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    }
  });
}).listen(5000);

console.log("Server running at http://localhost:5000");
